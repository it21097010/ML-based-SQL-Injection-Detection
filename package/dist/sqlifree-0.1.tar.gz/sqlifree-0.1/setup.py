from setuptools import setup, find_packages

setup(
    name='sqlifree',
    version='0.1',
    description='SQL Injection Free',
    author='Madhusha',
    author_email='madhusha@gmail.com',
    packages=['sqlifree'],
    install_requires=[
        'tensorflow',
    ],
)
